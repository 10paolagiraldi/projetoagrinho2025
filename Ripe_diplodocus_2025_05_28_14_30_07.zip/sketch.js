let money = 100;
let terrains = [];
const TERRAIN_SIZE = 60;
const GRID_COLS = 8;
const GRID_ROWS = 5;
const MARGIN_TOP = 80; // Espaço para a UI

let currentSeed = 'carrot'; // Semente selecionada inicialmente
let seeds = {
  carrot: { price: 10, growTime: 5000, color: '#FFA500' }, // 5 segundos
  wheat: { price: 15, growTime: 7000, color: '#F5DEB3' }   // 7 segundos
};

let carrotSeedButton;
let wheatSeedButton;
let moneyDisplay;

function setup() {
  createCanvas(TERRAIN_SIZE * GRID_COLS, TERRAIN_SIZE * GRID_ROWS + MARGIN_TOP);
  background(135, 206, 235); // Céu azul

  // Inicializa os terrenos
  for (let r = 0; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS; c++) {
      terrains.push(new Terrain(c * TERRAIN_SIZE, r * TERRAIN_SIZE + MARGIN_TOP, TERRAIN_SIZE));
    }
  }

  // Cria a interface de usuário (UI)
  createUI();
}

function draw() {
  background(135, 206, 235); // Limpa o background a cada frame para evitar rastros

  // Desenha os terrenos
  for (let i = 0; i < terrains.length; i++) {
    terrains[i].display();
    terrains[i].update(); // Atualiza o estado da planta
  }

  // Desenha a UI por último para ficar por cima
  drawUI();
}

function createUI() {
  // Botões de semente
  carrotSeedButton = createButton('Cenoura ($' + seeds.carrot.price + ')');
  carrotSeedButton.position(10, 10);
  carrotSeedButton.mousePressed(() => currentSeed = 'carrot');
  carrotSeedButton.style('background-color', '#FFA500');
  carrotSeedButton.style('color', 'white');
  carrotSeedButton.style('border', 'none');
  carrotSeedButton.style('padding', '8px 12px');
  carrotSeedButton.style('font-size', '14px');
  carrotSeedButton.style('cursor', 'pointer');

  wheatSeedButton = createButton('Trigo ($' + seeds.wheat.price + ')');
  wheatSeedButton.position(140, 10);
  wheatSeedButton.mousePressed(() => currentSeed = 'wheat');
  wheatSeedButton.style('background-color', '#F5DEB3');
  wheatSeedButton.style('color', 'black');
  wheatSeedButton.style('border', 'none');
  wheatSeedButton.style('padding', '8px 12px');
  wheatSeedButton.style('font-size', '14px');
  wheatSeedButton.style('cursor', 'pointer');

  // Display de dinheiro
  moneyDisplay = createElement('h3', 'Dinheiro: $' + money);
  moneyDisplay.position(width - 150, 10); // Posiciona à direita
  moneyDisplay.style('color', 'white');
}

function drawUI() {
  // Atualiza o display de dinheiro
  moneyDisplay.html('Dinheiro: $' + money);

  // Desenha a barra superior da UI
  fill(50, 50, 50, 200); // Fundo escuro transparente
  noStroke();
  rect(0, 0, width, MARGIN_TOP);

  // Indica a semente selecionada
  fill(255);
  textSize(16);
  textAlign(LEFT, CENTER);
  text('Semente selecionada: ' + currentSeed.toUpperCase(), 10, MARGIN_TOP - 25);
}


function mousePressed() {
  // Ignora cliques na área da UI
  if (mouseY < MARGIN_TOP) {
    return;
  }

  for (let i = 0; i < terrains.length; i++) {
    let t = terrains[i];
    if (mouseX > t.x && mouseX < t.x + t.size &&
        mouseY > t.y && mouseY < t.y + t.size) {
      if (t.state === 'empty') {
        // Tenta plantar
        let seedInfo = seeds[currentSeed];
        if (money >= seedInfo.price) {
          t.plant(currentSeed, seedInfo.growTime, seedInfo.color);
          money -= seedInfo.price;
        } else {
          console.log("Dinheiro insuficiente para plantar " + currentSeed);
        }
      } else if (t.state === 'grown') {
        // Tenta colher
        t.harvest();
        money += 20; // Ganha dinheiro ao colher (valor fixo por enquanto)
      }
      break; // Sai do loop depois de encontrar o terreno clicado
    }
  }
}

class Terrain {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.state = 'empty'; // 'empty', 'growing', 'grown'
    this.plantType = null;
    this.plantColor = null;
    this.growStartTime = 0;
    this.growTime = 0;
    this.growthProgress = 0; // 0 a 1
  }

  plant(type, time, color) {
    this.state = 'growing';
    this.plantType = type;
    this.plantColor = color;
    this.growStartTime = millis();
    this.growTime = time;
    this.growthProgress = 0;
  }

  update() {
    if (this.state === 'growing') {
      let elapsedTime = millis() - this.growStartTime;
      this.growthProgress = min(1, elapsedTime / this.growTime); // Garante que não passe de 1

      if (this.growthProgress >= 1) {
        this.state = 'grown';
      }
    }
  }

  display() {
    // Desenha o terreno
    fill(139, 69, 19); // Cor da terra
    stroke(50);
    rect(this.x, this.y, this.size, this.size);

    if (this.state === 'growing') {
      // Desenha a planta em crescimento
      fill(this.plantColor);
      let plantHeight = this.size * 0.2 + (this.size * 0.6 * this.growthProgress); // Começa pequena e cresce
      ellipse(this.x + this.size / 2, this.y + this.size, this.size * 0.4, plantHeight);
      
      // Barra de progresso (opcional, pode ser removida se poluir a tela)
      fill(0, 0, 0, 150);
      rect(this.x + this.size * 0.1, this.y + this.size * 0.85, this.size * 0.8, 5);
      fill(0, 255, 0);
      rect(this.x + this.size * 0.1, this.y + this.size * 0.85, this.size * 0.8 * this.growthProgress, 5);

    } else if (this.state === 'grown') {
      // Desenha a planta madura
      fill(this.plantColor);
      // Representação simples da planta madura
      ellipse(this.x + this.size / 2, this.y + this.size * 0.7, this.size * 0.6, this.size * 0.6);
      fill(255);
      textSize(12);
      textAlign(CENTER, CENTER);
      text('COLHER!', this.x + this.size / 2, this.y + this.size * 0.2); // Texto para colher
    }
  }

  harvest() {
    if (this.state === 'grown') {
      this.state = 'empty';
      this.plantType = null;
      this.plantColor = null;
      this.growStartTime = 0;
      this.growTime = 0;
      this.growthProgress = 0;
      console.log("Planta colhida!");
    }
  }
}